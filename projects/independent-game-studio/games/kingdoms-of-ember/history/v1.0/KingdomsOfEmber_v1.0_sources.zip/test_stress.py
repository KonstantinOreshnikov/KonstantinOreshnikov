import asyncio, pathlib
from playwright.async_api import async_playwright
P=pathlib.Path(__file__).with_name('index.html')
async def main():
 fail=[];count=0; n=0
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await browser.new_page()
  page.on('pageerror',lambda e:fail.append('js '+str(e)))
  shim='<script>const _store={};Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:k=>_store[k]??null,setItem:(k,v)=>_store[k]=String(v),removeItem:k=>delete _store[k]}});</script>'
  await page.set_content(P.read_text().replace('<head>','<head>'+shim,1))
  for scenario in range(4):
   await page.evaluate(f'__gameQA.newGame({scenario},"normal")')
   for i in range(20):
    # skip modal in stress runs if win triggered, and use same real-end-turn path
    await page.evaluate("document.querySelector('#overlay').classList.add('hidden')")
    await page.evaluate('__gameQA.performTurn()')
    await page.wait_for_timeout(145)
    st=await page.evaluate('__gameQA.getState()')
    count+=1
    if not await page.evaluate('__gameQA.validateGame(__gameQA.getState())'):
     fail.append((scenario,i,'failed save schema'))
    if any(g<0 for g in st['gold']):fail.append((scenario,i,'negative gold'))
    if len({(u['x'],u['y']) for u in st['units']})!=len(st['units']):fail.append((scenario,i,'overlapping armies'))
    if st['result']:
     print('Scenario',scenario,'completed',st['result'],'turn',st['turn']);break
  # recruitment costs and fly terrain
  r=await page.evaluate("""(()=>{__gameQA.newGame(0,'normal');const s=__gameQA.getState();const commander=__gameQA.unitAt(2,3);const moves=__gameQA.getMoves(commander);const kk=Object.keys(moves).find(k=>+k!==3*16+2);__gameQA.moveUnit(commander,+kk%16,Math.floor(+kk/16));const b=__gameQA.buildingAt(2,3);const old=__gameQA.getState().gold[0];const recruited=__gameQA.recruit('golem',b,0);const now=__gameQA.getState().gold[0];return {recruited,delta:old-now};})()""")
  if not (r['recruited'] and r['delta']==760): fail.append(('recruit_golem',r))
  # Validate fly unit and reject non-fly on mountain
  r=await page.evaluate("""(()=>{__gameQA.newGame(0,'normal');const s=__gameQA.getState();const king=__gameQA.unitAt(2,3);const b=__gameQA.buildingAt(2,3);let moves=__gameQA.getMoves(king);let k=Object.keys(moves)[0];__gameQA.moveUnit(king,+k%16,Math.floor(+k/16));const ok=__gameQA.recruit('wisp',b,0);const fly=__gameQA.unitAt(2,3);return {ok,fly:!!fly,reach:Object.keys(__gameQA.getMoves(fly)).length};})()""")
  if not (r['ok'] and r['fly'] and r['reach']==0):fail.append(('new_unit_no_instant_move',r))
  await page.evaluate('__gameQA.performTurn()')
  await page.wait_for_timeout(180)
  possible=await page.evaluate("(()=>{let fly=__gameQA.unitAt(2,3);return fly&&Object.keys(__gameQA.getMoves(fly)).length;})()")
  if not (possible and possible>0):fail.append(('flying_mobility',possible))
  print('STRESS',count,'turns | problems',len(fail),fail[:10])
  await browser.close()
if __name__=='__main__':asyncio.run(main())
