import asyncio, json, pathlib
from playwright.async_api import async_playwright
PATH=pathlib.Path(__file__).with_name('index.html').resolve()
async def main():
 checks=[];errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1440,'height':1000}, device_scale_factor=1)
  page.on('pageerror',lambda e: errors.append(str(e)))
  html=PATH.read_text(encoding='utf-8')
  shim='''<script>const _store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>_store[k]??null,setItem:(k,v)=>_store[k]=String(v),removeItem:k=>delete _store[k]}});</script>'''
  await page.set_content(html.replace('<head>','<head>'+shim,1),wait_until='load')
  await page.wait_for_timeout(300)
  async def ev(expr):return await page.evaluate(expr)
  def check(name,v):checks.append((name,bool(v)));print(('PASS' if v else 'FAIL'),name)
  check('initial render',await page.locator('#board').count()==1 and await page.locator('#mapTitle').inner_text()!='')
  check('zero JS errors',not errors)
  state=await ev('window.__gameQA.getState()')
  check('16x12 world',len(state['map'])==192 and len(state['buildings'])>=7)
  check('two live armies',sum(u['owner']==0 for u in state['units'])>=3 and sum(u['owner']==1 for u in state['units'])>=3)
  check('English switch', bool(await ev("(()=>{document.getElementById('lang').value='en';document.getElementById('lang').dispatchEvent(new Event('change'));return document.getElementById('endTurn').textContent==='End turn'})()")))
  check('Azerbaijani switch', bool(await ev("(()=>{document.getElementById('lang').value='az';document.getElementById('lang').dispatchEvent(new Event('change'));return document.getElementById('endTurn').textContent==='Gedişi bitir'})()")))
  check('Russian switch',bool(await ev("(()=>{document.getElementById('lang').value='ru';document.getElementById('lang').dispatchEvent(new Event('change'));return document.getElementById('endTurn').textContent==='Завершить ход'})()")))
  # move and preview parity
  moves=await ev("(()=>{const s=__gameQA.getState();const u=s.units.find(u=>u.owner===0&&u.type==='soldier');return {id:u.id,moves:__gameQA.getMoves(u)}})()")
  check('movement generated',len(moves['moves'])>0)
  pos=int(next(iter(moves['moves'])));x,y=pos%16,pos//16
  result=await ev(f"(()=>{{let u=__gameQA.getState().units.find(u=>u.id==={moves['id']});return __gameQA.moveUnit(window.__gameQA.getState().units.find(x=>x.id===-1),0,0)}})()")
  check('invalid move rejected',result==False)
  result=await ev(f"(()=>{{const u=window.__gameQA.unitAt(3,4);return u&&window.__gameQA.moveUnit(u,{x},{y})}})()")
  check('move processed',result==True)
  state2=await ev('__gameQA.getState()')
  check('no duplicate position',len({(u['x'],u['y']) for u in state2['units']})==len(state2['units']))
  check('combat bound', await ev("(()=>{let a=__gameQA.unitAt(2,3);let d=__gameQA.unitAt(13,8);return __gameQA.damageCalc(a,d)>=0})()"))
  check('cannot recruit on occupied keep',not await ev("(()=>{const b=__gameQA.buildingAt(2,3);return __gameQA.recruit('soldier',b,0)})()"))
  # switch to unoccupied castle through controlled state using newGame and captured building
  await ev("__gameQA.newGame(0,'normal')")
  captured=await ev("(()=>{let st=__gameQA.getState();let u=__gameQA.unitAt(2,3);u.x=5;u.y=5;return __gameQA.captureUnit(u);})()")
  check('capture town',bool(captured))
  check('income rises on capture',await ev("__gameQA.getState().buildings.find(b=>b.x===5&&b.y===5).owner===0"))
  # keep capture and victory
  await ev("__gameQA.newGame(0,'normal')")
  check('victory triggered on keep capture',await ev("(()=>{let u=__gameQA.unitAt(2,3);u.x=13;u.y=8;return __gameQA.captureUnit(u)&&__gameQA.getState().result==='win';})()"))
  await ev("__gameQA.newGame(0,'normal')")
  await ev("document.getElementById('overlay').classList.add('hidden')")
  await page.locator('#endTurn').click()
  await page.get_by_role('button',name='Да, продолжить').click()
  await page.wait_for_timeout(800)
  state3=await ev('__gameQA.getState()')
  check('AI turn completed',state3['turn']==2 and state3['side']==0)
  check('AI used economic budget',state3['gold'][1]>=0)
  check('AI leaves valid units',len({(u['x'],u['y']) for u in state3['units']})==len(state3['units']))
  check('persistent save',await ev("(()=>{let a=__gameQA.getState().turn;__gameQA.save();return __gameQA.load()&&__gameQA.getState().turn===a})()"))
  check('bad save rejected',not await ev("__gameQA.validateGame({v:1,map:[]})"))
  # UI click and screenshot
  await page.screenshot(path=str(PATH.parent/'desktop_preview.png'),full_page=True)
  await page.set_viewport_size({'width':390,'height':850})
  await page.screenshot(path=str(PATH.parent/'mobile_preview.png'),full_page=True)
  check('mobile canvas reachable',await page.locator('#board').is_visible())
  check('game remains error-free',not errors)
  print('RESULT',sum(ok for _,ok in checks),'/',len(checks),'ERRORS',errors[:3])
  await browser.close()
  return checks
if __name__=='__main__':asyncio.run(main())
