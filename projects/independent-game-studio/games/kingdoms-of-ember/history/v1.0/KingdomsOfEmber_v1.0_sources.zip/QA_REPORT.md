# Kingdoms of Ember v1.0 — QA summary

## Automated checks (2026-11-20)
- `python test_game.py`: **23/23 PASS**
- `python test_stress.py`: **4 completed seeded scenarios, 49 game turns, 0 reported invariant problems**
- Coverage: startup, 16×12 map, army setup, RU/EN/AZ, movement validation, combat bound, recruitment blockers, settlement capture and income, victory trigger, bot turn and economy, save and invalid-save handling, mobile game canvas, JavaScript error-free test execution.

## Limitations
- Browser tests do not prove all long campaigns are balanced.
- Visual inspection performed using generated desktop and mobile preview images, not every device/browser.
- Original game source code/sprites were not reused. This is a distinct fan-inspired tactical game, not a reproduction of all original Ancient Empires II missions.
